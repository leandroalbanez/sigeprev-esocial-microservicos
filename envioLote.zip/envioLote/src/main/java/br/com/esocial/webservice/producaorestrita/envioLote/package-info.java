@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esocial.gov.br/servicos/empregador/lote/eventos/envio/v1_1_0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.esocial.webservice.producaorestrita.envioLote;
